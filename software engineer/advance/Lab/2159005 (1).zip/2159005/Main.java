package test;

// Interface chung cho các nhân viên
interface Employee {
    void doTask();
    void join(String time);
    void terminate(String time);
}

// Implement cho Employee
class BaseEmployee implements Employee {
    protected String name;

    public BaseEmployee(String name) {
        this.name = name;
    }

    @Override
    public void doTask() {
        System.out.println(name + " is performing tasks.");
    }

    @Override
    public void join(String time) {
        System.out.println("The basic information of " + name);
        System.out.println(name + " joined on " + time);
    }

    @Override
    public void terminate(String time) {
        System.out.println(name + " terminated on " + time);
    }
}

// Decorator cho Team Member
class TeamMemberDecorator extends BaseEmployee {
    public TeamMemberDecorator(String name) {
        super(name);
    }

    @Override
    public void doTask() {
        System.out.println(name + " is reporting task.");
    }
}

// Decorator cho Team Leader
class TeamLeaderDecorator extends BaseEmployee {
    public TeamLeaderDecorator(String name) {
        super(name);
    }

    @Override
    public void doTask() {
        System.out.println(name + " is planning.");
        System.out.println(name + " is motivating his members.");
        System.out.println(name + " is monitoring his members.");
    }
}

// Decorator cho Manager
class ManagerDecorator extends BaseEmployee {
    public ManagerDecorator(String name) {
        super(name);
    }

    @Override
    public void doTask() {
        System.out.println(name + " is creating requirements.");
        System.out.println(name + " is assigning tasks.");
        System.out.println(name + " is managing the progress.");
    }
}

public class Main {
    public static void main(String[] args) {
        // Tạo một nhân viên cơ bản
        System.out.println("A: TEAM MEMBER: ");
        System.out.println("-------");
        Employee member = new TeamMemberDecorator("MEMBER");
        member.join("04/11/2018");
        member.terminate("04/05/2019");

        System.out.println(" ");

        System.out.println("B: TEAM LEADER:  ");
        System.out.println("-------");
        Employee leader = new TeamLeaderDecorator("LEADER");
        leader.join("04/11/2018");
        leader.terminate("04/05/2019");
        leader.doTask();

        System.out.println(" ");

        System.out.println("C: MANAGER:  ");
        System.out.println("-------");
        Employee manager = new ManagerDecorator("MANAGER");
        manager.join("04/11/2018");
        manager.terminate("04/05/2019");
        manager.doTask();

        System.out.println(" ");

        System.out.println("D: TEAM LEADER AND MANAGER:  ");
        System.out.println("-------");
        Employee leaderAndManager = new ManagerDecorator("L&M");
        //Employee managerAndLeader = new LeaderDecorator(name:"L&M");
        leaderAndManager.join("04/11/2018");
        leaderAndManager.terminate("04/05/2019");
        leaderAndManager.doTask();
        //managerAndLeader.doTask();
    }
}