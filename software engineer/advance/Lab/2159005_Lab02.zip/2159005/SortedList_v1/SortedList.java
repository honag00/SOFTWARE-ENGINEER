import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class SortedList {
    private int[] numbers;

    public SortedList(int size) {
        this.numbers = new int[size];
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            this.numbers[i] = rand.nextInt(100); 
        }
    }

    public void selectionSort() {
        for (int i = 0; i < numbers.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < numbers.length; j++) {
                if (numbers[j] < numbers[minIndex]) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                int temp = numbers[i];
                numbers[i] = numbers[minIndex];
                numbers[minIndex] = temp;
            }
        }
    }

    public void bubbleSort() {
        boolean swapped;
        do {
            swapped = false;
            for (int i = 0; i < numbers.length - 1; i++) {
                if (numbers[i] > numbers[i + 1]) {
                    int temp = numbers[i];
                    numbers[i] = numbers[i + 1];
                    numbers[i + 1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    }

    public void print() {
        System.out.println(Arrays.toString(this.numbers));
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Choose a sorting algorithm:");
            System.out.println("1/Selection Sort");
            System.out.println("2/Bubble Sort");

            int choice = scanner.nextInt();

            SortedList list = new SortedList(25);

            switch (choice) {
                case 1:
                    list.selectionSort();
                    break;
                case 2:
                    list.bubbleSort();
                    break;
                default:
                    System.out.println("Invalid choice");
                    return;
            }

            list.print();
        }
    }
}