package SortedList_v2;

import java.util.Arrays;
import java.util.Random;

public class SortedList {
    private int[] numbers;

    public SortedList(int size) {
        this.numbers = new int[size];
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            this.numbers[i] = rand.nextInt(100); 
        }
    }

    public void print() {
        System.out.println(Arrays.toString(this.numbers));
    }

    public void selectionSort() {
    }

    public void bubbleSort() {
    }
}