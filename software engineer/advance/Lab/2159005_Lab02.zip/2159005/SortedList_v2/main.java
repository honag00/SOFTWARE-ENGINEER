package SortedList_v2;

import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Choose a sorting algorithm:");
            System.out.println("1/Selection Sort");
            System.out.println("2/Bubble Sort");

            int choice = scanner.nextInt();

            SortedList list = new SortedList(25);

            switch (choice) {
                case 1:
                    list.selectionSort();
                    break;
                case 2:
                    list.bubbleSort();
                    break;
                default:
                    System.out.println("Invalid choice");
                    return;
            }

            list.print();
        }
    }
}