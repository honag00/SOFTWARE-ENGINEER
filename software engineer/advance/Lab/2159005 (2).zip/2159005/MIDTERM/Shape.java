package MIDTERM;

// Lớp Shape
public class Shape {
    private String name;
    private String borderStyle;
    private String borderColor;
    private String backgroundColor;
    private String backgroundPattern;
    private FillStrategy fillStrategy;
    private double width;
    private double length;
    private double radius;

    public Shape(String name, String borderStyle, String borderColor, String backgroundColor, String backgroundPattern, FillStrategy fillStrategy, double width, double length, double radius) {
        this.name = name;
        this.borderStyle = borderStyle;
        this.borderColor = borderColor;
        this.backgroundColor = backgroundColor;
        this.backgroundPattern = backgroundPattern;
        this.fillStrategy = fillStrategy;
        this.width = width;
        this.length = length;
        this.radius = radius;
    }

    public void draw() {
        System.out.println(name + ", " +"co " + "vien " + borderStyle + " mau " + borderColor +
                ", nen " + backgroundColor + " " + backgroundPattern +
                "va " + fillStrategy.fill() + 
                ", chieu rong: " + width + ", chieu dai: " + length + ", ban kinh: " + radius);
    }
}