package MIDTERM;

// Strategy Pattern: Định nghĩa interface cho việc tô nền
public interface FillStrategy {
    String fill();
}