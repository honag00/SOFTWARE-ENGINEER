package MIDTERM;

// Các implement của FillStrategy
public class RecursiveFillStrategy implements FillStrategy {
    @Override
    public String fill() {
        return "to de quy";
    }
}