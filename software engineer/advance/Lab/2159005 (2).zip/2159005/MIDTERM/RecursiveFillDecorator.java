package MIDTERM;

// Decorator Pattern: Decorator cho FillStrategy
public class RecursiveFillDecorator implements FillStrategy {
    private FillStrategy decoratedStrategy;

    public RecursiveFillDecorator(FillStrategy decoratedStrategy) {
        this.decoratedStrategy = decoratedStrategy;
    }

    @Override
    public String fill() {
        return decoratedStrategy.fill() + ", to de quy";
    }
}