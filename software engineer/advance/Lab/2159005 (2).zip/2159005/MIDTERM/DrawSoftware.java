package MIDTERM;

// Sử dụng
public class DrawSoftware {
    public static void main(String[] args) {
        // #1
        Shape square = ShapeFactory.createShape(10, 10, 0, "khong vien", null, "don sac trang", "", new RecursiveFillStrategy());
        square.draw();

        // #2
        Shape circle = ShapeFactory.createShape(0, 0, 5, "net dut", "den", "khong mau", "", new NonRecursiveFillStrategy());
        circle.draw();

        // #3
        FillStrategy recursiveFillStrategy = new NonRecursiveFillStrategy();
        Shape roundedRectangle = ShapeFactory.createShape(0, 0, 8, "net cham gach", "do", "chuyen sac radial vang-trang", "", recursiveFillStrategy);
        roundedRectangle.draw();
    }
}