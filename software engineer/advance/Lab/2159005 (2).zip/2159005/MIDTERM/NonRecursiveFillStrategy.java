package MIDTERM;

public class NonRecursiveFillStrategy implements FillStrategy {
    @Override
    public String fill() {
        return "to khong de quy";
    }
}