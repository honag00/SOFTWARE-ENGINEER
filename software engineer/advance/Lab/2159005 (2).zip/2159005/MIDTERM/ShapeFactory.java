package MIDTERM;

public class ShapeFactory {
    public static Shape createShape(double width, double length, double radius, String borderStyle, String borderColor, String backgroundColor, String backgroundPattern, FillStrategy fillStrategy) {
        if (width == length && radius == 0) {
            return new Shape("hinh vuong", borderStyle, borderColor, backgroundColor, backgroundPattern, fillStrategy, width, length, radius);
        } else if (radius != 0) {
            return new Shape("hinh tron", borderStyle, borderColor, backgroundColor, backgroundPattern, fillStrategy, width, length, radius);
        }
        else if (width < length || width > length && radius == 0){
            return new Shape("hinh thang", borderStyle, borderColor, backgroundColor, backgroundPattern, fillStrategy, width, length, radius);
        }

        // Add them cac hinh khac nhau
        return null;
    }
}