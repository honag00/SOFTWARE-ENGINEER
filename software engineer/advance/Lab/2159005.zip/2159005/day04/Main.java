package day04;

import model.Customer;
import model.Movie;
import model.Rental;

public class Main {
    public static void main(String[] args) {
        Customer customer = new Customer("Mr.2159005");

        Movie rogueOne = new Movie.NewReleaseMovie("Rogue One");
        Rental rental1 = new Rental(rogueOne, 5);
        customer.addRental(rental1);

        Movie frozen = new Movie.ChildrensMovie("Frozen");
        Rental rental2 = new Rental(frozen, 7);
        customer.addRental(rental2);

        Movie starWarsIII = new Movie.RegularMovie("Star Wars III");
        Rental rental3 = new Rental(starWarsIII, 4);
        customer.addRental(rental3);

        System.out.println(customer.htmlStatement());
    }
}