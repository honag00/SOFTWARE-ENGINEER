package model;

//import java.util.ArrayList;
import java.util.Vector;

public class Customer {
    private String name;
    private Vector<Rental> rentals = new Vector<>();

    public Customer(String name) {
        this.name = name;
    }

    public void addRental(Rental rental) {
        rentals.add(rental);
    }

    public String getName() {
        return name;
    }

    public String htmlStatement() {
        double totalAmount = 0;
        int frequentRenterPoints = 0;
        StringBuilder result = new StringBuilder("<h1>Rental Record for " + getName() + "</h1><br>");
    
        for (Rental rental : rentals) {
            double thisAmount = rental.getMovie().calculateAmount(rental.getDaysRented());
    
            frequentRenterPoints += rental.getMovie().calculateFrequentRenterPoints(rental.getDaysRented());
    
            result.append("<p>").append(rental.getMovie().getTitle()).append(": ").append(thisAmount).append("</p>");
            totalAmount += thisAmount;
        }
    
        result.append("<p>Amount owed is ").append(totalAmount).append("</p>");
        result.append("<p>You earned ").append(frequentRenterPoints).append(" frequent renter points</p>");
        return result.toString();
    }
}