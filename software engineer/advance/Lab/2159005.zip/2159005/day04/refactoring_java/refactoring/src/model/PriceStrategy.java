package model;

public abstract class PriceStrategy {
    public abstract int getPriceCode();

    public abstract double calculateAmount(int daysRented);

    public abstract int calculateFrequentRenterPoints(int daysRented);
}
