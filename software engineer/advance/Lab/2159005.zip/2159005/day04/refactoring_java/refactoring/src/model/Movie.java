package model;

public abstract class Movie {
    public static final int CHILDRENS = 2;
    public static final int REGULAR = 0;
    public static final int NEW_RELEASE = 1;

    private String title;
    private PriceStrategy priceStrategy;

    public Movie(String title, int priceCode) {
        this.title = title;
        setPriceCode(priceCode);
    }

    public int getPriceCode() {
        return priceStrategy.getPriceCode();
    }

    public void setPriceCode(int priceCode) {
        switch (priceCode) {
            case REGULAR:
                priceStrategy = new RegularPrice();
                break;
            case CHILDRENS:
                priceStrategy = new ChildrensPrice();
                break;
            case NEW_RELEASE:
                priceStrategy = new NewReleasePrice();
                break;
        }
    }

    public String getTitle() {
        return title;
    }

    public double calculateAmount(int daysRented) {
        return priceStrategy.calculateAmount(daysRented);
    }

    public int calculateFrequentRenterPoints(int daysRented) {
        return priceStrategy.calculateFrequentRenterPoints(daysRented);
    }

    public static class ChildrensMovie extends Movie {
        public ChildrensMovie(String title) {
            super(title, CHILDRENS);
        }
    }

    public static class RegularMovie extends Movie {
        public RegularMovie(String title) {
            super(title, REGULAR);
        }
    }

    public static class NewReleaseMovie extends Movie {
        public NewReleaseMovie(String title) {
            super(title, NEW_RELEASE);
        }
    }
}