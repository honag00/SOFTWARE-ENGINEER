package model;

public class NewReleasePrice extends PriceStrategy {
    @Override
    public int getPriceCode() {
        return 2;
    }

    @Override
    public double calculateAmount(int daysRented) {
        return daysRented * 3;
    }

    @Override
    public int calculateFrequentRenterPoints(int daysRented) {
        return (daysRented > 1) ? 2 : 1;
    }
}